function Problem1({studentName, course, section}) {
    return (
      <div>
        <h1>{studentName} - {course} {section}</h1>
      </div>
    );
  }
  
  export default Problem1;
  