import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';
export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);

  const [count, setCount] = useState(0);


  useEffect(() => {
    setTimeout(() => {
      setCount((count) => count + 1);
      if(setCount == 3) isLoading = false;
    }, 1000);
  });

  let count1 = count;
  if (count1 >= 3) {
    isLoading = false;
  } else {
    isLoading = true;
  }

  return (
    <>
      
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div style={{ display: 'block' }}>
            Input: <input type='text' />
            <p>User is idle...</p>
          </div>
        </>
      )}
    </>
  );
}
