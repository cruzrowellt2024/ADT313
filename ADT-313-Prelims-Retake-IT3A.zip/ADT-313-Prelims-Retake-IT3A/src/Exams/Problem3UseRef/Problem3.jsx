import {useRef} from "react";
function Problem3() {
  const inputRef1 = useRef();
  const inputRef2 = useRef();
  const inputRef3 = useRef();
  const inputRef4 = useRef();
  const inputRef5 = useRef();
  const inputRef6 = useRef();
  const inputRef7 = useRef();
  const inputRef8 = useRef();
  const inputRef9 = useRef();
  const inputRef10 = useRef();



  const focusInput = () => {
    if (inputRef1.current.value == ""){
      inputRef1.current.focus();
    } else if (inputRef2.current.value == ""){
      inputRef2.current.focus();
    } else if (inputRef3.current.value == ""){
      inputRef3.current.focus();
    } else if (inputRef4.current.value == ""){
      inputRef4.current.focus();
    } else if (inputRef5.current.value == ""){
      inputRef5.current.focus();
    } else if (inputRef6.current.value == ""){
      inputRef6.current.focus();
    } else if (inputRef7.current.value == ""){
      inputRef7.current.focus();
    } else if (inputRef8.current.value == ""){
      inputRef8.current.focus();
    } else if (inputRef9.current.value == ""){
      inputRef9.current.focus();
    } else if (inputRef10.current.value == ""){
      inputRef10.current.focus();
    }
  };

  return (
    <>
      <div ref={inputRef1} style={{ display: 'block' }}>
        Input 1: <input ref={inputRef1} type='text' />
      </div>
      <div ref={inputRef2} style={{ display: 'block' }}>
        Input 2: <input ref={inputRef2} type='text' />
      </div>
      <div  style={{ display: 'block' }}>
        Input 3: <input ref={inputRef3} type='text' />
      </div>
      <div ref={inputRef4} style={{ display: 'block' }}>
        Input 4: <input ref={inputRef4} type='text' />
      </div>
      <div ref={inputRef5} style={{ display: 'block' }}>
        Input 5: <input ref={inputRef5} type='text' />
      </div>
      <div ref={inputRef6} style={{ display: 'block' }}>
        Input 6: <input ref={inputRef6} type='text' />
      </div>
      <div ref={inputRef7} style={{ display: 'block' }}>
        Input 7: <input ref={inputRef7} type='text' />
      </div>
      <div ref={inputRef8} style={{ display: 'block' }}>
        Input 8: <input ref={inputRef8} type='text' />
      </div>
      <div ref={inputRef9} style={{ display: 'block' }}>
        Input 9: <input ref={inputRef9} type='text' />
      </div>
      <div ref={inputRef10} style={{ display: 'block' }}>
        Input 10: <input ref={inputRef10} type='text' />
      </div>
      <button type='button' onClick={focusInput}>I'm a button</button>
    </>
  );
}

export default Problem3;
